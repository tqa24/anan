var BT_MSG = {
	"ERROR":"Lỗi hệ thống",
	"SUCCESS":"Hoạt động thành công",
	"ADD_SUCCESS":"Thêm thành công",
	"ADD_ERROR":"Thêm không thành công",
	"DEL_SUCCESS":"Đã xóa thành công",
	"DEL_ERROR":"Không xóa được",
	"SET_SUCCESS":"Thiết lập thành công",
	"SET_ERROR":"Thiết lập không thành công",
	"PATH_ERROR":"Không thể sử dụng thư mục quan trọng của hệ thống làm thư mục trang web",
	"SITE_ADD_SUCCESS":"Trang web được tạo thành công!",
	"SITE_ADD_EXISTS":"Trang web bạn thêm đã tồn tại!",
	"SITE_ADD_PORT":"Dải cổng không hợp lệ",
	"SITE_DEL_SUCCESS":"Trang web đã được xóa thành công!",
	"SITE_ADD_DOMAIN":"Đã thêm tên miền thành công!",
	"SITE_ADD_EXISTS":"Tên miền được chỉ định đã bị ràng buộc!",
	"SITE_ADD_BINDING":"Tên miền và tên thư mục con không được để trống!"
}